# Copyright (c) The PyAMF Project.
# See LICENSE.txt for details.

"""
Python C-extensions for L{PyAMF<pyamf>}.

@since: 0.4
"""
