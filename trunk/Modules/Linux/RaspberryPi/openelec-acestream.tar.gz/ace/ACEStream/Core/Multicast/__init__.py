#Embedded file name: ACEStream\Core\Multicast\__init__.pyo
from Multicast import *
