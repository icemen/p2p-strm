#Embedded file name: ACEStream\Core\Subtitles\MetadataDomainObjects\__init__.pyo
pass
