#Embedded file name: ACEStream\Core\Search\__init__.pyo
pass
