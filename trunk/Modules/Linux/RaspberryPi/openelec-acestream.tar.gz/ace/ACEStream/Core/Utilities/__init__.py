#Embedded file name: ACEStream\Core\Utilities\__init__.pyo
pass
